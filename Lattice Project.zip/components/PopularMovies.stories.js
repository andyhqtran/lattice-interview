import React from 'react'

import { PopularMovies } from 'components/PopularMovies'

export default {
  title: 'PopularMovies',
  component: PopularMovies
}

export const example = () => {
  return (
    <PopularMovies />
  )
}
