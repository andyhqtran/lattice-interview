import React from 'react'

import { LatestMovies } from 'components/LatestMovies'

export default {
  title: 'LatestMovies',
  component: LatestMovies
}

export const example = () => {
  return (
    <LatestMovies />
  )
}
