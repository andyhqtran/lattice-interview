import React from 'react'

import { BackHomeButton } from 'components/BackHomeButton'

export default {
  title: 'BackHomeButton',
  component: BackHomeButton
}

export const example = () => {
  return (
    <BackHomeButton />
  )
}
