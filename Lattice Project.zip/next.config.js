module.exports = {
  env: {
    API_KEY: 'c1d8821ebc1867b1e20fc4996175525f'
  }
}
